package com.company;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Prodaja {
    int id;
    int id_prodaji;
    int id_prod;
    int id_tovar;
    int kolvo_prodaj;
    String data;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_prodaji() {
        return id_prodaji;
    }

    public void setId_prodaji(int id_prodaji) {
        this.id_prodaji = id_prodaji;
    }

    public int getId_prod() {
        return id_prod;
    }

    public void setId_prod(int id_prod) {
        this.id_prod = id_prod;
    }

    public int getId_tovar() {
        return id_tovar;
    }

    public void setId_tovar(int id_tovar) {
        this.id_tovar = id_tovar;
    }

    public int getKolvo_prodaj() {
        return kolvo_prodaj;
    }

    public void setKolvo_prodaj(int kolvo_prodaj) {
        this.kolvo_prodaj = kolvo_prodaj;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Prodaja{" +
                "id=" + id +
                ", id_prodaji=" + id_prodaji +
                ", id_prod=" + id_prod +
                ", id_tovar=" + id_tovar +
                ", kolvo_prodaj=" + kolvo_prodaj +
                ", data='" + data + '\'' +
                '}';
    }
}
