package com.company;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class Kolvo_Productov {

    @XmlElement

    List<Kolvo_Producta> Kolvo_Producta = new ArrayList<>();

    public List<com.company.Kolvo_Producta> getKolvo_Producta() {
        return Kolvo_Producta;
    }

    public void setKolvo_Producta(List<com.company.Kolvo_Producta> kolvo_Producta) {
        Kolvo_Producta = kolvo_Producta;
    }

    @Override
    public String toString() {
        return "Kolvo_Productov{" +
                "Kolvo_Producta=" + Kolvo_Producta +
                '}';
    }
}
