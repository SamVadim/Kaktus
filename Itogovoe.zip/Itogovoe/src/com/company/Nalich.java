package com.company;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Nalich {
    int id_prod;
    int id_tovar;
    int cena;
    int kolvo;


    public int getId_prod() {
        return id_prod;
    }

    public void setId_prod(int id_prod) {
        this.id_prod = id_prod;
    }

    public int getId_tovar() {
        return id_tovar;
    }

    public void setId_tovar(int id_tovar) {
        this.id_tovar = id_tovar;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public int getKolvo() {
        return kolvo;
    }

    public void setKolvo(int kolvo) {
        this.kolvo = kolvo;
    }

    @Override
    public String toString() {
        return "Nalich{" +
                "id_prod=" + id_prod +
                ", id_tovar=" + id_tovar +
                ", cena=" + cena +
                ", kolvo=" + kolvo +
                '}';
    }
}
