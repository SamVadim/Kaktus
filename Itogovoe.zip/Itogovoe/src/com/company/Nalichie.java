package com.company;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
@XmlRootElement(name = "nalichya")
@XmlAccessorType(XmlAccessType.NONE)
public class Nalichie {

    @XmlElement(name = "nalichie")
    List<Nalich> nalich = new ArrayList<>();

    public List<Nalich> getNalich() {
        return nalich;
    }

    public void setNalich(List<Nalich> nalich) {
        this.nalich = nalich;
    }
}
