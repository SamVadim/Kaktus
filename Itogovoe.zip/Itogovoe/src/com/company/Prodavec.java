package com.company;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Prodavec {
    int id;
    String l_name;
    String f_name;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    @Override
    public String toString() {
        return "Prodavec{" +
                "id=" + id +
                ", l_name=" + l_name +
                ", f_name=" + f_name +
                '}';
    }
}
