package com.company;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Kolvo_Producta {
    String name;
    int kolvo;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getKolvo() {
        return kolvo;
    }

    public void setKolvo(int kolvo) {
        this.kolvo = kolvo;
    }

    @Override
    public String toString() {
        return "Kolvo_Producta{" +
                "name='" + name + '\'' +
                ", kolvo=" + kolvo +
                '}';
    }
}
