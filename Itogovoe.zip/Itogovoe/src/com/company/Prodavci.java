package com.company;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
@XmlRootElement(name = "people")
@XmlAccessorType(XmlAccessType.NONE)
public class Prodavci {

    @XmlElement(name = "person")
    List<Prodavec> prodavci = new ArrayList<>();

    public List<Prodavec> getProdavci() {
        return prodavci;
    }

    public void setProdavci(List<Prodavec> prodavci) {
        this.prodavci = prodavci;
    }


}
