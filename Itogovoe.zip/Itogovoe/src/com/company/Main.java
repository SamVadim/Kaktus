package com.company;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Main {

    public static void main(String[] args) throws JAXBException {


        Unmarshaller unmarshaller = JAXBContext.newInstance(Prodavci.class, Prodavec.class, Tovars.class, Tovar.class, Nalich.class, Nalichie.class, Prodaja.class, Prodaji.class).createUnmarshaller();



        Prodavci Kassirs = (Prodavci) unmarshaller.unmarshal(new File("Prodavci.XML"));

        Tovars Korobka = (Tovars) unmarshaller.unmarshal(new File("Tovar.XML"));

        Nalichie INNAL = (Nalichie) unmarshaller.unmarshal(new File("Nalichie.XML"));

        Prodaji Prodano = (Prodaji) unmarshaller.unmarshal(new File("Prodaji.XML"));


   /*     for(Prodavec x: Kassirs.getProdavci()){
            System.out.println(x);
        }

        for(Tovar x: Korobka.getTovars()){
            System.out.println(x);
        }

        for(Nalich x: INNAL.getNalich()){
            System.out.println(x);
        }

        for(Prodaja x: Prodano.getProdaji()){
            System.out.println(x);
        }
   */

        Map<Integer, String> tovar = new TreeMap<>();

        for(Tovar x: Korobka.getTovars()){
            tovar.put(x.getId(), x.getName());
        }


        Map<Integer, Integer> nalichie = new TreeMap<>();

        for(Nalich x: INNAL.getNalich()){
            int key = x.getId_tovar();
            int value = x.getKolvo();

            try{

                nalichie.put(key,nalichie.get(key) + value);

            }catch(NullPointerException e){
                nalichie.put(key,value);
            }

        }
        //System.out.println(nalichie);

        List<Kolvo_Producta> Kol_vo = new ArrayList<>();


        for(Integer x: tovar.keySet()){
            Kolvo_Producta ans = new Kolvo_Producta();

            ans.setName(tovar.get(x));
            ans.setKolvo(nalichie.get(x));
            Kol_vo.add(ans);
        }

        Kolvo_Productov answer = new Kolvo_Productov();

        answer.setKolvo_Producta(Kol_vo);

        System.out.println(answer);
        Marshaller marshaller = JAXBContext.newInstance(Kolvo_Productov.class, Kolvo_Producta.class).createMarshaller();

        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(answer, new File("Otvetik1.XML"));
    }
}
